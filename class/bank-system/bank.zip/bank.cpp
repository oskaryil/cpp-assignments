// Author: Oskar Yildiz
// Version: 1.0.0 
// Assignment: Bankaccount Main

#include <iostream>
#include "bankaccount.h"

using namespace std;

int main() {

  // First parameter is accountnumber, second parameter is initial account balance.
  BankAccount Oskar(123456, 100); 

  cout << "Current balance: " << Oskar.getBalance() << endl;
  cout << "Adding 500" << endl;
  Oskar.makeTransaction(500);
  cout << "New Balance: " << Oskar.getBalance() << endl;
  return 0;
}