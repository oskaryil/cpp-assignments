// Author: Oskar Yildiz
// Version: 1.0.0 
// Assignment: Bankaccount class with account number and balance

#include "bankaccount.h"

// double BankAccount::getBalance() {
//   return accountBalance;
// }

// double BankAccount::makeTransaction(double amount) {
//   return accountBalance+amount;
// }

